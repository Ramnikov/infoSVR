--           Licensed Materials - Property of IBM
--           Copyright IBM Corp. 2013, 2014
----------------------------------------------------------------------------
-- IBM InfoSphere DataStage and QualityStage ExceptionStage 
-- new database permissions granting for DB2
----------------------------------------------------------------------------

CONNECT TO ESDBDB2;

GRANT CREATETAB,IMPLICIT_SCHEMA,CONNECT,QUIESCE_CONNECT,LOAD,BINDADD,DATAACCESS ON DATABASE TO USER esuser;
GRANT USE OF TABLESPACE ESDBSPACE TO USER esuser;
CREATE SCHEMA esuser;
GRANT ALTERIN, CREATEIN, DROPIN ON SCHEMA esuser TO USER esuser;

COMMIT;

CONNECT RESET;
