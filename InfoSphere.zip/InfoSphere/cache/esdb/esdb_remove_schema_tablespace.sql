--           Licensed Materials - Property of IBM
--           Copyright IBM Corp. 2013, 2014
--------------------------------------------------------------------------------
-- IBM InfoSphere DataStage and QualityStage ExceptionStage database schema removal
-- for DB2
--------------------------------------------------------------------------------
CONNECT TO ESDBDB2;
DROP SCHEMA esuser RESTRICT;
DROP TABLESPACE ESDBSPACE;
DROP TABLESPACE TEMPESDBSPACE;
DROP BUFFERPOOL ESDBPOOL;
COMMIT;

CONNECT RESET;
-- Uncomment the following line if you intend to drop the ESDB database and it is not xmeta.
-- DROP DATABASE ESDBDB2;