--           Licensed Materials - Property of IBM
--           Copyright IBM Corp. 2013, 2014
--------------------------------------------------------------------------------
-- IBM InfoSphere DataStage and QualityStage ExceptionStage database creation
-- for DB2
--
-- ExceptionStage database: create main audit + metrics tables
-- 
-- The ESDB repository user must be connected to the database before running this script.
--
CREATE TABLE esuser.DQC_DESCRIPTOR (
     RID                  VARGRAPHIC(30) NOT NULL,
     ROW_COUNT 			  BIGINT,
     APPLICATIONID 		  VARGRAPHIC(50),
     HOSTNAME 			  VARGRAPHIC(255),
     PROJECTNAME 		  VARGRAPHIC(50),
     JOBNAME 			  VARGRAPHIC(50),
     STAGENAME 			  VARGRAPHIC(50),
     TIMESTAMP 			  VARGRAPHIC(50),
     DESCRIPTION          VARGRAPHIC(300),
     EXCEPTIONNAME        VARGRAPHIC(300),
     REPLICATE_TIMESTAMP  VARGRAPHIC(50)
    )IN ESDBSPACE;

CREATE TABLE esuser.DQC_DESCRIPTOR_MVALUE (
     RID         VARGRAPHIC(30) NOT NULL,
     PROP_NAME   VARGRAPHIC(50),
     PROP_VALUE  VARGRAPHIC(1280),
     RECLEVEL    VARGRAPHIC(50)
    )IN ESDBSPACE;

COMMIT;

CONNECT RESET;