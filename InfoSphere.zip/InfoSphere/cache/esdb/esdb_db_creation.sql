--           Licensed Materials - Property of IBM
--           Copyright IBM Corp. 2013, 2014
--------------------------------------------------------------------------------
-- IBM InfoSphere DataStage and QualityStage ExceptionStage database creation - part 1 - 
-- for DB2
--------------------------------------------------------------------------------
--
-- The settings in this file are the ones that are recommended for creating and 
-- configuring a DB2 database to be used as the IBM InfoSphere DataStage and QualityStage 
-- ExceptionStage database.
--
--------------------------------------------------------------------------------

-- CODESET:
-- ========
--   This creates a database with the recommended codeset of UTF-8. If the 
--   database is configured to use another codeset, data entered or transferred
--   that contains characters not supported by the configured codeset will not
--   be stored, processed or displayed correctly by IBM InfoSphere QualityStage.
--   To avoid issues with unsupported characters use the UTF-8 
--   codeset.
--
-- COLLATE:
-- ========
--   With the Identity collating sequence, strings are compared byte for byte.
--   Identity is the default for Unicode databases. The value of this property 
--   impacts the way strings are compared and sorted in a query. To ensure case 
--   sensitive query behavior, the Identity collation must be used. 
--
--   Recommendation: Use IDENTITY collation regardless of the CODESET to ensure 
--   consistent query behavior. 
--
-- AUTOCONFIGURE:
-- ==============
--   DB2 will automatically configure 25% of physical memory for the database
--   and the USERSPACE1 tablespace will automatically be configured to use 
--   automatic storage, with an initial size of 1GB

CREATE DATABASE ESDBDB2 ON '/opt/IBM/InformationServer/Repos/esdb/'	      
       USING CODESET UTF-8 TERRITORY US 
       COLLATE USING IDENTITY
       DFT_EXTENT_SZ 2
       USER TABLESPACE
         MANAGED BY AUTOMATIC STORAGE
         AUTORESIZE YES
         INITIALSIZE 500 M
         INCREASESIZE 10 PERCENT
         MAXSIZE NONE;

-- QUERY_HEAP_SZ
-- =============
--   Query heap size. This parameter specifies the maximum amount of memory that
--   can be allocated for the query heap. The default is 1000.
--
--   Recommendation: Set the value of QUERY_HEAP_SZ to 4096.

UPDATE DBM CFG USING QUERY_HEAP_SZ 4096 IMMEDIATE;

-- ASLHEAPSZ
-- =========
--   Application support layer heap size. The default is 15.
-- 
--   Recommendation: Set the value of ASLHEAPSZ to 1024.

UPDATE DBM CFG USING ASLHEAPSZ 1024 IMMEDIATE;

-- AGENT_STACK_SZ  
-- ==============
--   Agent stack size. The virtual memory that is allocated to each agent by 
--   DB2. The stack increases when the complexity of the query increases. The 
--   memory is committed when each SQL statement is processed. When preparing a 
--   large SQL statement, the agent can run out of stack space and the system 
--   will generate a stack overflow exception. When this happens, the server 
--   will shut down because the error is non-recoverable. The agent stack size
--   and the number of concurrent clients are inversely related: a larger stack
--   size reduces the potential number of concurrent clients that can be 
--   running. The default value is 64. 
--
--   Recommendation: Set the value of agent_stack_sz to 256.

UPDATE DBM CFG USING agent_stack_sz  256 IMMEDIATE;

-- STMTHEAP      
-- ========  
--   Statement heap size. If you have very large SQL statements and the database
--   manager issues an error (that the statement is too complex) when it 
--   attempts to optimize a statement, you should increase the value of this 
--   parameter in regular increments (such as 256 or 1024) until the error 
--   situation is resolved. The default value is 2048.
--
--   Recommendation: Set the value of STMTHEAP to 10240.

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING STMTHEAP 10240;

-- APPLHEAPSZ      
-- ==========
--   Application heap size. The value of this parameter must be increased if 
--   your applications receive an error indicating that there is not enough 
--   storage in the application heap. The default value is 256.
--
--   Recommendation: Set the value of STMTHEAP to 4096.

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING APPLHEAPSZ 4096 IMMEDIATE ;

-- DFT_MON monitor switches:
-- =========================
--   By default, all the DFT_MON switches are disabled except DFT_MON_TIMESTAMP.
--   All the switches will incur some sort of overhead - in particular, as CPU 
--   approaches 100%, DFT_MON_TIMESTAMP will have an increasing effect on 
--   performance.
--
--   Recommendation: Leave default for all DFT_MON switches (off), except 
--   DFT_MON_TIMESTAMP which should explicitly be disabled.

UPDATE DBM CFG USING DFT_MON_TIMESTAMP OFF IMMEDIATE;

-- AVG_APPLS
-- =========
--   Average number of active applications. Used by the query optimizer to help
--   estimate how much buffer pool will be available at run-time for the access
--   plan chosen.

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING AVG_APPLS 5 IMMEDIATE;

-- DBHEAP
-- ======
--   Database Heap.

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING DBHEAP 4096 IMMEDIATE ;

-- SELF_TUNING_MEM:
-- ================
--   New to v9, DB2 has the ability to self-tune a number of memory related 
--   parameters. These parameters are:
--
--    DATABASE_MEMORY
--    LOCKLIST 
--    MAXLOCKS 
--    PCKCACHESZ 
--    SHEAPTHRES_SHR 
--    SORTHEAP 
--    STMTHEAP (9.5)
--    DBHEAP (9.5)
--    APPLHEAPSZ (9.5)
--
--   By default, all these parameters are enabled for self tuning memory apart
--   from SHEAPTHRES_SHR.
--
--   Recommendation: Enable all parameters for self-tuning memory since this is 
--   an autonomic feature which should mean less intervention and administration
--   of the database is required.

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING SHEAPTHRES_SHR AUTOMATIC;

-- Logging configuration
-- =====================

UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING LOGBUFSZ 2048 IMMEDIATE;
UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING LOGFILSIZ 1000;
UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING LOGPRIMARY 50;
UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING LOGSECOND 200;
