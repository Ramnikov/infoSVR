--           Licensed Materials - Property of IBM
--           Copyright IBM Corp. 2013, 2014
--------------------------------------------------------------------------------
-- IBM InfoSphere DataStage and QualityStage ExceptionStage database creation - part 2 - 
-- for DB2
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 
-- The settings in this file are the ones that are recommended for creating and 
-- configuring buffer pools and tablespaces for the IBM InfoSphere DataStage and QualityStage 
-- ExceptionStage database.
--
CONNECT TO ESDBDB2;

-- Bufferpools
-- ============
--   In DB2 9 bufferpools have the ability to be managed by the self-tuning 
--   memory feature. To be able to support installation in a variety of
--   environments this setting is used.
CREATE BUFFERPOOL ESDBPOOL IMMEDIATE 
       SIZE 8000 AUTOMATIC 
       NUMBLOCKPAGES 2048 BLOCKSIZE 32
       PAGESIZE 32 K ;

-- DMS Tablespace
-- ==============
--   Create a DMS tablespace with 32k pagesize to hold wide tables whose storage
--   is automatically managed by DB2

CREATE REGULAR TABLESPACE ESDBSPACE
       IN DATABASE PARTITION GROUP IBMDEFAULTGROUP 
       PAGESIZE 32768 
       MANAGED BY AUTOMATIC STORAGE
       AUTORESIZE YES
       INITIALSIZE 500 M
       INCREASESIZE 10 PERCENT
       MAXSIZE NONE
       EXTENTSIZE 16
       BUFFERPOOL ESDBPOOL
       FILE SYSTEM CACHING  
       DROPPED TABLE RECOVERY ON;

COMMIT WORK;

-- SMS Tablespace
-- ==============
--   Create a temporary SMS tablespace for the ESDB regular tablespace whose 
--   storage is automatically managed by DB2

CREATE TEMPORARY TABLESPACE TEMPESDBSPACE  
       IN DATABASE PARTITION GROUP IBMTEMPGROUP 
       PAGESIZE 32768 
       MANAGED BY AUTOMATIC STORAGE
       EXTENTSIZE 16
       BUFFERPOOL ESDBPOOL
       FILE SYSTEM CACHING;

COMMENT ON TABLESPACE TEMPESDBSPACE IS '32 page swap';


COMMIT;

CONNECT RESET;
UPDATE DATABASE CONFIGURATION FOR ESDBDB2 USING LOGFILSIZ 10000;
